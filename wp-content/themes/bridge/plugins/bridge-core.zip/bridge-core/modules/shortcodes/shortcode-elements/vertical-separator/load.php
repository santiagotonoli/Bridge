<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/vertical-separator/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/vertical-separator/vertical-separator.php';