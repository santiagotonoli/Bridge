<?php

include_once QODE_LMS_CPT_PATH . '/course/course-register.php';
include_once QODE_LMS_CPT_PATH . '/course/helper-functions.php';
include_once QODE_LMS_CPT_PATH . '/course/profile/profile-functions.php';
include_once QODE_LMS_CPT_PATH . '/course/shortcodes/shortcodes-functions.php';