<div class="qode-course-content">
	<h4 class="qode-course-content-title"><?php esc_html_e( 'About this course', 'qode-lms' ) ?></h4>
	<?php the_content(); ?>
</div>