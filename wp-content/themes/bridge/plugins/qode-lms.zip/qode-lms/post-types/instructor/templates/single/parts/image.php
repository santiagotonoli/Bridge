<div class="qode-instructor-image">
	<?php the_post_thumbnail(); ?>
</div>